---
name: expertise-poesie
description: Analyse de mes textes de rap/slam/paroles (qualité, rimes, punchlines, suites logiques, références). Utiliser dès qu'un texte est collé ou qu'un fichier .txt de rap est donné pour l'analyser, noter, critiquer. Vérifie les références sur le web. Sortie ultra-concise.
---

# Analyse rap/slam/paroles

Entrée : texte de l'auteur (fichier ou collé). Pas de préambule, ne pas recopier le texte, pas de termes vulgaires dans l'analyse (les citer par n° de vers).

## Modes

- **Bref (défaut)** : aucune question, sortie ci-dessous.
- **Complet** (si « complet », « détaillé », « à fond ») : poser UNE question QCM si instrumental/BPM/style inconnu et susceptible de changer la note, puis ajouter les sections demandées (profils, passages faibles, artiste cible, suites logiques).

## Sortie bref (~5 lignes)

```
Note : X/10 (ou /100 si demandé)
+ Force : …
- Faiblesse : …
→ Priorité : …
```

## Critères

- Qualité : images fraîches vs clichés, rimes (multisyllabiques, internes, rimes faciles), punchlines.
- Suites logiques : chaque punchline se relie-t-elle à la précédente ? Signaler les ruptures par n° de vers.
- Structure : jugée seulement si l'instrumental est connu (elle en dépend).
- Si l'instrumental est connu (ex. boom bap) : réajuster (densité acceptée, chutes sur le temps, longueur des vers).

## Références (étape obligatoire en mode complet, sur demande en bref)

1. Lister les références douteuses (noms propres, expressions, argot, marques).
2. Les vérifier avec WebSearch en parallèle (une requête par référence, une seule salve).
3. Rapporter : trouvée (source) / introuvable (probable invention → à clarifier ou couper) / lien non établi.
4. Ne pas vérifier ce qui est évident (Verlaine, Moïse…) ; le signaler « connaissance générale ».
5. Terminer par `Sources:` en liens markdown.

## Notes et profils (sur demande)

- Note /100 par profil : auditeur quotidien (valorise densité/références) vs lambda (valorise accroche, clarté, refrain mémorisable). Donner l'écart en une ligne et la cause.
- Artiste cible (ghostwriting) : 1 meilleur fit + 2 alternatives + 1 écarté, chacun en ≤ 12 mots.

## Règles

- Citer par n° de vers (`v3`, `v7-8`), jamais de longs extraits.
- Puces ≤ 20 mots, concrètes (vers visé + pourquoi).
- Pas de réécriture sauf demande ; alors uniquement les vers modifiés : `vN : avant → après`.
- Si le fichier a changé depuis la dernière analyse, relire et ne signaler que les écarts.
- Noter sans complaisance ; incertain = `?`.
- Ne pas reproduire de paroles protégées non fournies.
