# Context notes

## Couple / marriage
Topics: household labor, finances, career moves, where to live, holidays, in-laws, parenting, personal time, big purchases.
- Aim: a system for deciding together, not a ruling on authority. Agree *how* you decide (e.g. purchases above X need both; each owns certain domains).
- Name the issue neutrally; avoid "always/never". One issue per conversation, when neither is tired, hungry or rushed.
- Fairness is felt, not just counted: ask each what "fair" means; split by capacity, preference and cost, not mechanically 50/50.
- Use trials ("try this for a month, review first weekend of next month") and scheduled reviews instead of reopening ad hoc.
- No scorekeeping, silent treatment or guilt. Repair after conflict is part of the agreement.
- Non-negotiable: safety, respect, honesty, core commitments. Don't trade these.

## Parenting
Separate **non-negotiable** (safety, health, respect) from **autonomy zones**. Offer bounded choices: "Teeth now. Before or after pajamas?"
- Toddlers: 2 choices, short, calm, follow through. Never negotiate safety.
- School age: give reasons, input on routines, simple trades with consistent follow-through.
- Teens: negotiate privileges and limits together, agree consequences in advance, grow autonomy as trust is shown, set review points.
- Don't bargain mid-tantrum; resolve later, calmly. No threats you won't carry out.

## Workplace / salary / contracts
- Prep market data and evidence of value; know the BATNA (other offers, current job).
- Negotiate the total package (base, bonus, equity, title, scope, flexibility, learning, review date), not only base.
- Ask for a specific number/range with a reason; anchor high within defensibility; let them respond.
- Conflicts with colleagues/boss: separate person from work issue, ask about their constraints, propose a trial, confirm in writing.
- Saying no to extra work: state what you protect and offer a trade ("I can take X if Y moves").

## Money / everyday disputes
- Know your walk-away price; compare alternatives; ask for better terms politely with a reason.
- Disputes: facts, desired remedy, deadline, written record; escalate in steps.
- With friends/family: lend only what you can afford to lose; put terms in writing.
