# Tactics (ethical use only: they clarify and persuade, never deceive)

## Understanding the other side
- **Label emotion**: "It sounds like you're worried about...". Naming negatives defuses them. Pause; let them confirm or correct.
- **Mirror**: repeat their last 1-3 key words as a question to draw out more.
- **Accusation audit**: pre-empt the worst thing they might think ("You may feel I'm pushing this too fast...").
- **Summarize until you hear "That's right"** (not "You're right", which just ends the exchange).
- **Calibrated questions** ("How"/"What", rarely "Why", which sounds accusatory): "How does this work for you?", "What would need to be true for this to work?". They make the other side solve your problem.
- Ask before disclosing: learn their priorities across issues before showing yours. Different priorities = tradeable value.

## Numbers and offers
- **Anchor first when you know the range**; otherwise let them go first. Ambitious but defensible, with a reason (criteria, precedent, market data). Against an extreme anchor, reject it explicitly and re-anchor; don't split the difference.
- **Objective criteria** (market data, precedent, expert, policy) turn "my will vs. yours" into "what's fair".
- **Package offers, not single-issue haggling**: offer 2-3 equivalent-value packages (MESO) and see which they pick; the choice reveals priorities.
- **Concessions**: decreasing size, each conditional ("If you can do X, I can do Y"). Never concede alone; trade. A precise, non-round final number signals a real limit.
- **Logrolling and contingent deals**: trade what you value little for what you value more; use contingencies (bonus, review clause, trial) when you disagree about the future.
- **Split-the-difference trap**: rewards the more extreme opener. Use only when both starts were reasonable.

## Pressure and hardball
- **Deadline / "take it or leave it"**: test if real; ask what happens at the deadline. Real: respond with a fast package. False: calm repetition.
- **Good cop/bad cop, higher authority, late nibbling**: name the pattern calmly; trade any late request for something.
- **Silence**: stay comfortable after a proposal; whoever fills it usually concedes.
- **Anger or stonewalling**: label, slow down, ask a calibrated question, or break with a return time.
- **"No"**: information about an interest, not an end. Ask "What would make this a yes?"
- Bad faith (lying, bluffing about alternatives): verify, don't retaliate in kind, strengthen BATNA, put it in writing.

## Process
- Negotiate the process if stuck (agenda, order, who decides, timing).
- Easy issues first for momentum, unless one blocking issue defines the value; then bundle.
- Multiparty: map deciders vs. influencers; secure allies first; look for coalitions; the "no" often comes from someone not in the room.
- Confirm any verbal deal in writing.

## Biases to check in yourself
Anchoring, loss aversion (reframe concessions as trades), sunk cost, fixed-pie assumption, reactive devaluation (dismissing an idea because the other side proposed it), overconfidence about BATNA, escalation of commitment, mood-driven concessions.
