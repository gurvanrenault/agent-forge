# Templates

## Prep sheet (blank)
- Problem (neutral):
- My interests / Their interests (hypotheses + how to test):
- My BATNA / Their BATNA / Reservation point:
- Flexible / Important / Non-negotiable:
- ZOPA plausible?
- Options (>=3 packages):
- Opening offer / target / floor:
- Concession plan (conditional trades):
- Key questions:
- Proposal script: "What if X? That gives you Y while I keep Z."
- Risks and replies:
- Closing: decision, owners, timing, change trigger, review date:

## Debrief (after an important negotiation)
1. Did I understand their interests? 2. Did I state mine clearly? 3. Did I stay respectful? 4. Did I protect legitimate boundaries? 5. Any unnecessary concessions? 6. Did I consider alternatives? 7. Did I prioritize the long-term relationship? 8. Can both sides realistically keep the agreement? 9. What will I do differently?

Record: initial positions, interests, BATNA, boundaries, concessions, final deal, lessons.

## Practice
- In every practice round, Claude gives a Best move + Why it works block after each of your turns (see SKILL.md).
- Weekly: one minor disagreement; Listen -> Clarify -> Interests -> Options -> Agree.
- Monthly: debrief one significant negotiation using the record above.
- Target: say "I understand why you want this" without agreeing, and "I disagree" without attacking.
